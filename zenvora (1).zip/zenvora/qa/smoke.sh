#!/usr/bin/env bash
# QA smoke test against a running stack (docker compose up -d).
# Usage: WEB_URL=http://localhost:8081 API_URL=http://localhost:8080 ./qa/smoke.sh
set -euo pipefail
API_URL="${API_URL:-http://localhost:8080}"
WEB_URL="${WEB_URL:-http://localhost:${WEB_PORT:-80}}"
SHOPS="clothes tshirts watches aircooler coolingglass specs washingmachine"
pass=0

ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; exit 1; }

echo "Waiting for gateway at $API_URL ..."
for i in $(seq 1 40); do
  curl -fsS "$API_URL/health" >/dev/null 2>&1 && break
  [ "$i" = 40 ] && bad "gateway did not become healthy in 80s"
  sleep 2
done
ok "gateway health"

count=$(curl -fsS "$API_URL/api/categories" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{const a=JSON.parse(s);console.log(a.filter(c=>c.available).length)})')
[ "$count" = 7 ] && ok "all 7 shops available" || bad "expected 7 shops, got $count"

for shop in $SHOPS; do
  n=$(curl -fsS "$API_URL/api/$shop/products" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>console.log(JSON.parse(s).length))')
  [ "$n" -ge 8 ] && ok "$shop returns $n products" || bad "$shop returned only $n products"
  img=$(curl -fsS "$API_URL/api/$shop/products" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>console.log(JSON.parse(s)[0].image))')
  code=$(curl -s -o /dev/null -w '%{http_code}' "$WEB_URL$img")
  [ "$code" = 200 ] && ok "$shop image served ($img)" || bad "$shop image returned $code ($img)"
done

code=$(curl -s -o /dev/null -w '%{http_code}' "$WEB_URL/")
[ "$code" = 200 ] && ok "storefront loads" || bad "storefront returned $code"
curl -fsS "$WEB_URL/api/watches/products?sort=price_asc" >/dev/null && ok "frontend proxies /api to gateway" || bad "frontend cannot reach gateway"
code=$(curl -s -o /dev/null -w '%{http_code}' "$API_URL/api/watches/products/99999")
[ "$code" = 404 ] && ok "unknown product gives 404" || bad "expected 404, got $code"

echo "All $pass checks passed."
