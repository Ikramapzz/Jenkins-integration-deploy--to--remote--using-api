"use strict";
// QA gate: every product must be well formed and have a real image file on disk.
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const shops = fs.readdirSync(root).filter((d) => d.endsWith("-service"));
let errors = 0;
let total = 0;
const fail = (msg) => { errors += 1; console.error("FAIL  " + msg); };

for (const dir of shops) {
  const products = require(path.join(root, dir, "src", "data.js"));
  const meta = require(path.join(root, dir, "src", "meta.js"));
  const names = new Set();
  if (products.length < 8) fail(`${dir}: only ${products.length} products (need 8+)`);
  for (const p of products) {
    total += 1;
    const label = `${dir} #${p.id} ${p.name}`;
    if (names.has(p.name)) fail(label + ": duplicate name");
    names.add(p.name);
    if (!(p.price > 0 && p.price <= p.mrp)) fail(label + ": price must be > 0 and <= mrp");
    if (!p.description || p.description.length < 20) fail(label + ": description too short");
    if (!p.image.startsWith(`/images/${meta.key}/`)) fail(label + ": image path not in its own folder");
    const file = path.join(root, "frontend", "public", p.image);
    if (!fs.existsSync(file)) fail(label + ": missing image " + p.image);
    else if (fs.statSync(file).size < 200) fail(label + ": image file looks empty");
  }
}
console.log(`Checked ${total} products across ${shops.length} shops, ${errors} problem(s).`);
process.exit(errors ? 1 : 0);
