# Zenvora QA test plan

| Layer | What is checked | Where it runs |
|-------|-----------------|---------------|
| Static check | Every source file parses (`node --check`) | Jenkins "Static Check", `npm run lint` |
| Unit and API tests | Health, meta, list, search, price filter, sort, product by id, 404, 405, bad input (14 per shop, 8 for gateway) | Jenkins "Unit and API Tests", `npm test` |
| Data and asset validation | 8+ products per shop, unique names, price <= MRP, image file exists | `node qa/validate-assets.js` |
| Code quality | Bugs, smells, coverage, quality gate | SonarQube |
| Image scan | HIGH and CRITICAL CVEs in every image | Trivy |
| Integration smoke | Full stack through compose: gateway, 7 shops, images, nginx proxy | `qa/smoke.sh` |

## Manual checks before release
1. Open the storefront, confirm all seven shops show with images.
2. Search "cooler": only Air Coolers should remain. Search "zzz": empty-state message shows.
3. Sort a shop by price, low to high, and confirm the order.
4. Add two items, change quantity, remove one, refresh the page: cart persists.
5. Place order: cart empties and the demo message appears.
6. Stop one shop container (`docker compose stop specs-service`): the Specs section shows "closed for a moment", other shops keep working.
