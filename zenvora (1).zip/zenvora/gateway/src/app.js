"use strict";
const http = require("http");

const CATEGORIES = [
  {
    "key": "clothes",
    "port": 3001
  },
  {
    "key": "tshirts",
    "port": 3002
  },
  {
    "key": "watches",
    "port": 3003
  },
  {
    "key": "aircooler",
    "port": 3004
  },
  {
    "key": "coolingglass",
    "port": 3005
  },
  {
    "key": "specs",
    "port": 3006
  },
  {
    "key": "washingmachine",
    "port": 3007
  }
];

function defaultUpstreams(env) {
  const source = env || process.env;
  const map = {};
  for (const c of CATEGORIES) {
    map[c.key] = source["UPSTREAM_" + c.key.toUpperCase()] || "http://" + c.key + "-service:" + c.port;
  }
  return map;
}

function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
    "Access-Control-Allow-Origin": "*",
  });
  res.end(payload);
}

function proxy(req, res, target, path) {
  const u = new URL(path, target);
  const upstreamReq = http.request(
    {
      hostname: u.hostname,
      port: u.port,
      path: u.pathname + u.search,
      method: req.method,
      headers: Object.assign({}, req.headers, { host: u.host }),
    },
    (upstreamRes) => {
      res.writeHead(upstreamRes.statusCode, upstreamRes.headers);
      upstreamRes.pipe(res);
    }
  );
  upstreamReq.setTimeout(5000, () => upstreamReq.destroy(new Error("timeout")));
  upstreamReq.on("error", () => {
    if (!res.headersSent) return send(res, 502, { error: "Shop is temporarily unavailable" });
    res.end();
  });
  req.pipe(upstreamReq);
}

async function loadCategories(upstreams) {
  const results = await Promise.all(
    CATEGORIES.map(async (c) => {
      try {
        const r = await fetch(upstreams[c.key] + "/meta", { signal: AbortSignal.timeout(3000) });
        if (!r.ok) throw new Error("bad status");
        return Object.assign(await r.json(), { available: true });
      } catch (err) {
        return { key: c.key, label: c.key, tagline: "", count: 0, available: false };
      }
    })
  );
  return results;
}

function createServer(upstreams) {
  const routes = upstreams || defaultUpstreams();
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (path === "/health") return send(res, 200, { status: "UP", service: "gateway" });
    if (path === "/api/categories") return send(res, 200, await loadCategories(routes));

    const match = path.match(/^\/api\/([a-z]+)(\/.*)?$/);
    if (match && routes[match[1]]) {
      return proxy(req, res, routes[match[1]], (match[2] || "/") + url.search);
    }
    return send(res, 404, { error: "Route not found" });
  });
}

module.exports = { createServer, defaultUpstreams, CATEGORIES };
