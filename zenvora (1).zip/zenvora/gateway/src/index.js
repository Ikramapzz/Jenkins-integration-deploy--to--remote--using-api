"use strict";
const { createServer } = require("./app");

const PORT = Number(process.env.PORT) || 8080;
const server = createServer();

server.listen(PORT, "0.0.0.0", () => console.log("gateway listening on " + PORT));

function shutdown() {
  server.close(() => process.exit(0));
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
