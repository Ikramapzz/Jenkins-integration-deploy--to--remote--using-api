"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const http = require("http");
const { createServer, CATEGORIES, defaultUpstreams } = require("../src/app");

const fakes = [];
let gateway;
let base;
const upstreams = {};

function listen(server) {
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve(server.address().port)));
}

before(async () => {
  for (const c of CATEGORIES) {
    if (c.key === "specs") {
      upstreams[c.key] = "http://127.0.0.1:1"; // nothing listens here: simulates a down shop
      continue;
    }
    const fake = http.createServer((req, res) => {
      res.setHeader("Content-Type", "application/json");
      if (req.url === "/meta") return res.end(JSON.stringify({ key: c.key, label: c.key, tagline: "t", count: 2 }));
      if (req.url.startsWith("/products")) return res.end(JSON.stringify([{ id: 1, url: req.url, from: c.key }]));
      res.statusCode = 404;
      res.end(JSON.stringify({ error: "nope" }));
    });
    fakes.push(fake);
    upstreams[c.key] = "http://127.0.0.1:" + (await listen(fake));
  }
  gateway = createServer(upstreams);
  base = "http://127.0.0.1:" + (await listen(gateway));
});

after(async () => {
  await Promise.all([gateway, ...fakes].map((s) => new Promise((r) => s.close(r))));
});

test("health returns UP", async () => {
  const res = await fetch(base + "/health");
  assert.equal(res.status, 200);
  assert.equal((await res.json()).service, "gateway");
});

test("gateway knows all seven shops", () => {
  assert.equal(CATEGORIES.length, 7);
  const map = defaultUpstreams({});
  assert.equal(map.watches, "http://watches-service:3003");
});

test("env var overrides an upstream", () => {
  const map = defaultUpstreams({ UPSTREAM_WATCHES: "http://localhost:9999" });
  assert.equal(map.watches, "http://localhost:9999");
});

test("categories lists every shop and flags the one that is down", async () => {
  const res = await fetch(base + "/api/categories");
  const body = await res.json();
  assert.equal(body.length, 7);
  assert.equal(body.find((c) => c.key === "specs").available, false);
  assert.equal(body.find((c) => c.key === "watches").available, true);
});

test("requests are proxied to the right shop with the query string", async () => {
  const res = await fetch(base + "/api/watches/products?sort=price_asc");
  const body = await res.json();
  assert.equal(res.status, 200);
  assert.equal(body[0].from, "watches");
  assert.equal(body[0].url, "/products?sort=price_asc");
});

test("upstream 404 is passed through", async () => {
  const res = await fetch(base + "/api/clothes/unknown");
  assert.equal(res.status, 404);
});

test("down shop returns 502 and does not crash the gateway", async () => {
  const res = await fetch(base + "/api/specs/products");
  assert.equal(res.status, 502);
  const health = await fetch(base + "/health");
  assert.equal(health.status, 200);
});

test("unknown category returns 404", async () => {
  const res = await fetch(base + "/api/toys/products");
  assert.equal(res.status, 404);
});
