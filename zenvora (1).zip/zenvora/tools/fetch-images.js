"use strict";
// Downloads real HD product photos from Pexels (free, commercial use allowed, attribution appreciated)
// and points each product's `image` field at the downloaded file.
//
//   PEXELS_API_KEY=your_key node tools/fetch-images.js            # fetch missing photos
//   PEXELS_API_KEY=your_key node tools/fetch-images.js --force    # re-download everything
//   PEXELS_API_KEY=your_key node tools/fetch-images.js --shop watches
//
// Get a free key at https://www.pexels.com/api/ (takes a minute). Needs Node 18+.
const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const API = process.env.PEXELS_API_BASE || "https://api.pexels.com/v1";
const KEY = process.env.PEXELS_API_KEY;
const FORCE = process.argv.includes("--force");
const onlyShop = process.argv.includes("--shop") ? process.argv[process.argv.indexOf("--shop") + 1] : null;
const SIZE = process.env.IMAGE_SIZE || "large2x"; // large2x is about 1880px wide; "original" is the full upload

if (!KEY) {
  console.error("Set PEXELS_API_KEY first. Free key: https://www.pexels.com/api/");
  process.exit(1);
}

const queries = require("./image-queries.json");
const creditsFile = path.join(ROOT, "frontend", "public", "images", "CREDITS.json");
const credits = fs.existsSync(creditsFile) ? JSON.parse(fs.readFileSync(creditsFile, "utf8")) : {};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function search(query) {
  const url = `${API}/search?query=${encodeURIComponent(query)}&per_page=5&orientation=landscape`;
  const res = await fetch(url, { headers: { Authorization: KEY } });
  if (res.status === 401) throw new Error("Pexels rejected the API key");
  if (res.status === 429) throw new Error("Pexels rate limit hit, wait an hour and run again (finished photos are kept)");
  if (!res.ok) throw new Error("Pexels search failed: HTTP " + res.status);
  return (await res.json()).photos || [];
}

async function download(url, file) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("download failed: HTTP " + res.status);
  fs.writeFileSync(file, Buffer.from(await res.arrayBuffer()));
}

(async () => {
  let done = 0, skipped = 0, failed = 0;
  for (const shop of Object.keys(queries)) {
    if (onlyShop && shop !== onlyShop) continue;
    const dataFile = path.join(ROOT, shop + "-service", "src", "data.js");
    const items = require(dataFile);
    for (let i = 0; i < items.length; i++) {
      const p = items[i];
      const base = p.image.replace(/\.[a-z]+$/i, "");
      const rel = base + ".jpg";
      const file = path.join(ROOT, "frontend", "public", rel);
      if (!FORCE && fs.existsSync(file)) { p.image = rel; skipped++; continue; }
      const q = queries[shop][i] || p.name;
      try {
        const photos = await search(q);
        if (!photos.length) throw new Error("no photo found for '" + q + "'");
        const photo = photos[0];
        await download(photo.src[SIZE] || photo.src.large2x, file);
        p.image = rel;
        credits[rel] = { product: p.name, query: q, photographer: photo.photographer, page: photo.url };
        done++;
        console.log(`ok    ${shop}/${p.name}  <-  ${q}`);
      } catch (err) {
        failed++;
        console.error(`FAIL  ${shop}/${p.name}: ${err.message}`);
        if (/rate limit|rejected/.test(err.message)) { save(dataFile, shop, items); process.exit(1); }
      }
      await sleep(350);
    }
    save(dataFile, shop, items);
  }
  fs.writeFileSync(creditsFile, JSON.stringify(credits, null, 2) + "\n");
  console.log(`\nDownloaded ${done}, kept ${skipped}, failed ${failed}. Failed products keep their SVG illustration.`);
  process.exit(failed ? 2 : 0);
})();

function save(dataFile, shop, items) {
  const header = `"use strict";\n// Add a product by appending an object here and dropping its image in frontend/public/images/${shop}/\n`;
  fs.writeFileSync(dataFile, header + "module.exports = " + JSON.stringify(items, null, 2) + ";\n");
}
