"use strict";
module.exports = {
  "key": "washingmachine",
  "label": "Washing Machines",
  "tagline": "Front load, top load and washer-dryers",
  "port": 3007
};
