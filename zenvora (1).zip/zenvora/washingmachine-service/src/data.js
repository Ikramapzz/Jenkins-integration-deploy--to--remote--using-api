"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/washingmachine/
module.exports = [
  {
    "id": 1,
    "name": "Front Load 7kg 5-Star",
    "price": 28999,
    "mrp": 35999,
    "rating": 4.5,
    "description": "7 kg front loader with 15 wash programs and a 1200 rpm spin.",
    "image": "/images/washingmachine/front-load-7kg-5-star.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Front Load 8kg Inverter",
    "price": 33999,
    "mrp": 41999,
    "rating": 4.0,
    "description": "Inverter motor with steam wash and a 10 year motor warranty.",
    "image": "/images/washingmachine/front-load-8kg-inverter.svg"
  },
  {
    "id": 3,
    "name": "Top Load 7.5kg 5-Star",
    "price": 18999,
    "mrp": 23999,
    "rating": 4.7,
    "description": "Top loader with a pulsator, soak mode and a lint filter.",
    "image": "/images/washingmachine/top-load-7-5kg-5-star.svg"
  },
  {
    "id": 4,
    "name": "Top Load 9kg Turbo",
    "price": 22999,
    "mrp": 28999,
    "rating": 4.2,
    "description": "Large 9 kg drum with a turbo wash action for heavy loads.",
    "image": "/images/washingmachine/top-load-9kg-turbo.svg"
  },
  {
    "id": 5,
    "name": "Semi-Automatic 8kg Twin Tub",
    "price": 11999,
    "mrp": 14999,
    "rating": 4.9,
    "description": "Separate wash and spin tubs with a rust-proof body.",
    "image": "/images/washingmachine/semi-automatic-8kg-twin-tub.svg"
  },
  {
    "id": 6,
    "name": "Fully Auto 6.5kg Compact",
    "price": 14999,
    "mrp": 18999,
    "rating": 4.4,
    "description": "Compact fully automatic machine for small families and flats.",
    "image": "/images/washingmachine/fully-auto-6-5kg-compact.svg"
  },
  {
    "id": 7,
    "name": "Washer-Dryer 8/6kg Combo",
    "price": 44999,
    "mrp": 54999,
    "rating": 3.9,
    "description": "Washes 8 kg and dries 6 kg in a single machine.",
    "image": "/images/washingmachine/washer-dryer-8-6kg-combo.svg"
  },
  {
    "id": 8,
    "name": "Smart Wi-Fi Front Load 9kg",
    "price": 49999,
    "mrp": 59999,
    "rating": 4.6,
    "description": "Wi-Fi controlled front loader with auto detergent dosing.",
    "image": "/images/washingmachine/smart-wi-fi-front-load-9kg.svg",
    "tag": "New"
  }
];
