"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/watches/
module.exports = [
  {
    "id": 1,
    "name": "Chronos Classic Leather",
    "price": 4999,
    "mrp": 6999,
    "rating": 4.1,
    "description": "Slim 40 mm steel case on a brown leather strap with a sunburst dial.",
    "image": "/images/watches/chronos-classic-leather.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Aurum Gold Dial",
    "price": 8499,
    "mrp": 11999,
    "rating": 4.8,
    "description": "Gold-tone case and dial with sapphire-coated glass and date window.",
    "image": "/images/watches/aurum-gold-dial.svg"
  },
  {
    "id": 3,
    "name": "Steel Chronograph",
    "price": 6999,
    "mrp": 9499,
    "rating": 4.3,
    "description": "Three sub-dial chronograph on a solid stainless steel bracelet.",
    "image": "/images/watches/steel-chronograph.svg"
  },
  {
    "id": 4,
    "name": "Minimal Mesh Silver",
    "price": 3999,
    "mrp": 5499,
    "rating": 3.8,
    "description": "Ultra-thin silver watch with a mesh strap and a clean white face.",
    "image": "/images/watches/minimal-mesh-silver.svg"
  },
  {
    "id": 5,
    "name": "Smart Fit Pro",
    "price": 5499,
    "mrp": 7999,
    "rating": 4.5,
    "description": "AMOLED smartwatch with heart-rate, sleep tracking and 7-day battery.",
    "image": "/images/watches/smart-fit-pro.svg"
  },
  {
    "id": 6,
    "name": "Diver 200M",
    "price": 9999,
    "mrp": 13999,
    "rating": 4.0,
    "description": "200 m water resistant diver with a rotating bezel and luminous markers.",
    "image": "/images/watches/diver-200m.svg"
  },
  {
    "id": 7,
    "name": "Rose Gold Ladies",
    "price": 4599,
    "mrp": 6499,
    "rating": 4.7,
    "description": "Rose gold case with a slim blush dial and a soft leather strap.",
    "image": "/images/watches/rose-gold-ladies.svg"
  },
  {
    "id": 8,
    "name": "Vintage Automatic",
    "price": 12999,
    "mrp": 17999,
    "rating": 4.2,
    "description": "Self-winding automatic movement with an exhibition case back.",
    "image": "/images/watches/vintage-automatic.svg"
  },
  {
    "id": 9,
    "name": "Digital Sport Shock",
    "price": 1999,
    "mrp": 2999,
    "rating": 4.9,
    "description": "Shock-resistant digital watch with stopwatch, alarm and backlight.",
    "image": "/images/watches/digital-sport-shock.svg"
  },
  {
    "id": 10,
    "name": "Pilot Field Watch",
    "price": 5999,
    "mrp": 8499,
    "rating": 4.4,
    "description": "Matte black field watch with a high-contrast dial and canvas strap.",
    "image": "/images/watches/pilot-field-watch.svg",
    "tag": "New"
  }
];
