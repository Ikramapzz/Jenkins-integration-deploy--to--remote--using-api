"use strict";
module.exports = {
  "key": "watches",
  "label": "Watches",
  "tagline": "Leather, steel, smart and automatic",
  "port": 3003
};
