"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/clothes/
module.exports = [
  {
    "id": 1,
    "name": "Linen Casual Shirt",
    "price": 1299,
    "mrp": 1899,
    "rating": 3.9,
    "description": "Breathable pure linen shirt with a relaxed collar, made for hot afternoons.",
    "image": "/images/clothes/linen-casual-shirt.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Slim Fit Chinos",
    "price": 1599,
    "mrp": 2299,
    "rating": 4.6,
    "description": "Stretch cotton chinos with a tapered leg and a clean flat front.",
    "image": "/images/clothes/slim-fit-chinos.svg"
  },
  {
    "id": 3,
    "name": "Denim Trucker Jacket",
    "price": 2999,
    "mrp": 4299,
    "rating": 4.1,
    "description": "Mid-wash denim jacket with chest pockets and a brushed cotton lining.",
    "image": "/images/clothes/denim-trucker-jacket.svg"
  },
  {
    "id": 4,
    "name": "Cotton Kurta Set",
    "price": 1899,
    "mrp": 2699,
    "rating": 4.8,
    "description": "Soft cotton kurta with matching pyjama, ready for festivals and family dinners.",
    "image": "/images/clothes/cotton-kurta-set.svg"
  },
  {
    "id": 5,
    "name": "Fleece Zip Hoodie",
    "price": 1799,
    "mrp": 2499,
    "rating": 4.3,
    "description": "Heavy fleece hoodie with a full zip and two deep front pockets.",
    "image": "/images/clothes/fleece-zip-hoodie.svg"
  },
  {
    "id": 6,
    "name": "Formal Blazer Navy",
    "price": 4499,
    "mrp": 6499,
    "rating": 3.8,
    "description": "Two-button navy blazer with a structured shoulder and half-lined body.",
    "image": "/images/clothes/formal-blazer-navy.svg"
  },
  {
    "id": 7,
    "name": "Track Joggers",
    "price": 999,
    "mrp": 1499,
    "rating": 4.5,
    "description": "Lightweight joggers with an elastic waist, zip pockets and a tapered cuff.",
    "image": "/images/clothes/track-joggers.svg"
  },
  {
    "id": 8,
    "name": "Silk Blend Saree",
    "price": 3499,
    "mrp": 4999,
    "rating": 4.0,
    "description": "Silk blend saree with a woven border and a matching blouse piece.",
    "image": "/images/clothes/silk-blend-saree.svg"
  },
  {
    "id": 9,
    "name": "Wool Overcoat",
    "price": 5999,
    "mrp": 8999,
    "rating": 4.7,
    "description": "Long wool-blend overcoat with a notch lapel for cold-weather travel.",
    "image": "/images/clothes/wool-overcoat.svg"
  },
  {
    "id": 10,
    "name": "Printed Cotton Dress",
    "price": 1699,
    "mrp": 2399,
    "rating": 4.2,
    "description": "Knee-length cotton dress with a small floral print and side pockets.",
    "image": "/images/clothes/printed-cotton-dress.svg",
    "tag": "New"
  }
];
