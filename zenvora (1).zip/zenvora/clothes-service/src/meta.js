"use strict";
module.exports = {
  "key": "clothes",
  "label": "Clothes",
  "tagline": "Shirts, jackets, kurtas and everyday wear",
  "port": 3001
};
