"use strict";
module.exports = {
  "key": "tshirts",
  "label": "T-Shirts",
  "tagline": "Polos, oversized tees and gym basics",
  "port": 3002
};
