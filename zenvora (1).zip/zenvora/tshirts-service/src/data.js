"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/tshirts/
module.exports = [
  {
    "id": 1,
    "name": "Classic Crew Tee",
    "price": 499,
    "mrp": 799,
    "rating": 4.0,
    "description": "Everyday 180 GSM cotton crew neck that keeps its shape after washing.",
    "image": "/images/tshirts/classic-crew-tee.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Pique Polo",
    "price": 899,
    "mrp": 1299,
    "rating": 4.7,
    "description": "Textured pique polo with a two-button placket and ribbed collar.",
    "image": "/images/tshirts/pique-polo.svg"
  },
  {
    "id": 3,
    "name": "Oversized Drop-Shoulder Tee",
    "price": 799,
    "mrp": 1199,
    "rating": 4.2,
    "description": "Roomy 240 GSM tee with dropped shoulders and a boxy fit.",
    "image": "/images/tshirts/oversized-drop-shoulder-tee.svg"
  },
  {
    "id": 4,
    "name": "Henley Full Sleeve",
    "price": 999,
    "mrp": 1399,
    "rating": 4.9,
    "description": "Full sleeve henley with a three-button placket in soft slub cotton.",
    "image": "/images/tshirts/henley-full-sleeve.svg"
  },
  {
    "id": 5,
    "name": "Breton Striped Tee",
    "price": 699,
    "mrp": 999,
    "rating": 4.4,
    "description": "Navy and white striped tee with a boat neck and a regular fit.",
    "image": "/images/tshirts/breton-striped-tee.svg"
  },
  {
    "id": 6,
    "name": "V-Neck Basic Pack of 3",
    "price": 1199,
    "mrp": 1799,
    "rating": 3.9,
    "description": "Three plain V-neck tees in black, white and grey for layering.",
    "image": "/images/tshirts/v-neck-basic-pack-of-3.svg"
  },
  {
    "id": 7,
    "name": "Raglan Baseball Tee",
    "price": 749,
    "mrp": 1099,
    "rating": 4.6,
    "description": "Contrast three-quarter sleeves with a soft combed cotton body.",
    "image": "/images/tshirts/raglan-baseball-tee.svg"
  },
  {
    "id": 8,
    "name": "Graphic Print Tee",
    "price": 649,
    "mrp": 949,
    "rating": 4.1,
    "description": "Regular fit tee with a bold chest print that will not crack in the wash.",
    "image": "/images/tshirts/graphic-print-tee.svg"
  },
  {
    "id": 9,
    "name": "Gym Dry-Fit Tee",
    "price": 599,
    "mrp": 899,
    "rating": 4.8,
    "description": "Moisture-wicking polyester tee with flat seams for workouts.",
    "image": "/images/tshirts/gym-dry-fit-tee.svg"
  },
  {
    "id": 10,
    "name": "Mandarin Collar Tee",
    "price": 849,
    "mrp": 1199,
    "rating": 4.3,
    "description": "Short sleeve tee with a small stand collar, smart enough for the office.",
    "image": "/images/tshirts/mandarin-collar-tee.svg",
    "tag": "New"
  }
];
