"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/coolingglass/
module.exports = [
  {
    "id": 1,
    "name": "Anti-Glare Polarized Driving",
    "price": 1999,
    "mrp": 2999,
    "rating": 4.3,
    "description": "Polarized lenses that cut road glare, with a lightweight TR90 frame.",
    "image": "/images/coolingglass/anti-glare-polarized-driving.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "UV400 Aviator Gold",
    "price": 2499,
    "mrp": 3599,
    "rating": 3.8,
    "description": "Classic aviator with a gold metal frame and UV400 protected lenses.",
    "image": "/images/coolingglass/uv400-aviator-gold.svg"
  },
  {
    "id": 3,
    "name": "Mirror Sport Wrap",
    "price": 2199,
    "mrp": 3199,
    "rating": 4.5,
    "description": "Wraparound mirror lenses with a grippy nose pad for running and cycling.",
    "image": "/images/coolingglass/mirror-sport-wrap.svg"
  },
  {
    "id": 4,
    "name": "Classic Wayfarer Black",
    "price": 1799,
    "mrp": 2599,
    "rating": 4.0,
    "description": "Glossy black wayfarer frame with dark gradient lenses.",
    "image": "/images/coolingglass/classic-wayfarer-black.svg"
  },
  {
    "id": 5,
    "name": "Round Retro Tortoise",
    "price": 1999,
    "mrp": 2799,
    "rating": 4.7,
    "description": "Round tortoise-shell frame with brown tinted lenses.",
    "image": "/images/coolingglass/round-retro-tortoise.svg"
  },
  {
    "id": 6,
    "name": "Oversized Cat-Eye",
    "price": 2299,
    "mrp": 3299,
    "rating": 4.2,
    "description": "Oversized cat-eye frame with full UV protection and a soft finish.",
    "image": "/images/coolingglass/oversized-cat-eye.svg"
  },
  {
    "id": 7,
    "name": "Photochromic Sun-to-Clear",
    "price": 3499,
    "mrp": 4999,
    "rating": 4.9,
    "description": "Lenses darken in sunlight and turn clear indoors.",
    "image": "/images/coolingglass/photochromic-sun-to-clear.svg"
  },
  {
    "id": 8,
    "name": "Kids UV Flex",
    "price": 999,
    "mrp": 1499,
    "rating": 4.4,
    "description": "Bendable frame with UV400 lenses sized for ages 4 to 10.",
    "image": "/images/coolingglass/kids-uv-flex.svg",
    "tag": "New"
  }
];
