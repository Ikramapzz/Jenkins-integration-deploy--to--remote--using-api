"use strict";
module.exports = {
  "key": "coolingglass",
  "label": "Cooling Glasses",
  "tagline": "Polarized, UV400 and photochromic sunglasses",
  "port": 3005
};
