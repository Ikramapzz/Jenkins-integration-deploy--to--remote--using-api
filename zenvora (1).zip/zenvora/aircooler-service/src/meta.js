"use strict";
module.exports = {
  "key": "aircooler",
  "label": "Air Coolers",
  "tagline": "Tower, desert and personal coolers",
  "port": 3004
};
