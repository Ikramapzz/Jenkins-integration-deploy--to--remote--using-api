"use strict";
const { createServer } = require("./app");
const meta = require("./meta");

const PORT = Number(process.env.PORT) || meta.port;
const server = createServer();

server.listen(PORT, "0.0.0.0", () => {
  console.log(meta.key + "-service listening on " + PORT);
});

function shutdown() {
  server.close(() => process.exit(0));
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
