"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/aircooler/
module.exports = [
  {
    "id": 1,
    "name": "Personal Cooler 25L",
    "price": 5999,
    "mrp": 7999,
    "rating": 4.2,
    "description": "Compact 25 litre cooler for a study table or a small bedroom.",
    "image": "/images/aircooler/personal-cooler-25l.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Tower Cooler 40L",
    "price": 8499,
    "mrp": 10999,
    "rating": 4.9,
    "description": "Slim tower design with a 3-speed fan and a dust filter.",
    "image": "/images/aircooler/tower-cooler-40l.svg"
  },
  {
    "id": 3,
    "name": "Desert Cooler 55L",
    "price": 10999,
    "mrp": 13999,
    "rating": 4.4,
    "description": "Powerful desert cooler for halls up to 250 sq ft with a large water tank.",
    "image": "/images/aircooler/desert-cooler-55l.svg"
  },
  {
    "id": 4,
    "name": "Desert Cooler 80L Inverter-Ready",
    "price": 13499,
    "mrp": 16999,
    "rating": 3.9,
    "description": "80 litre tank with a high-speed motor that runs on an inverter.",
    "image": "/images/aircooler/desert-cooler-80l-inverter-ready.svg"
  },
  {
    "id": 5,
    "name": "Window Cooler 50L",
    "price": 9499,
    "mrp": 12499,
    "rating": 4.6,
    "description": "Window-mount cooler with a thick honeycomb pad and auto swing louvers.",
    "image": "/images/aircooler/window-cooler-50l.svg"
  },
  {
    "id": 6,
    "name": "Mini Room Cooler 18L",
    "price": 4499,
    "mrp": 5999,
    "rating": 4.1,
    "description": "Lightweight 18 litre cooler with a handle and two speed settings.",
    "image": "/images/aircooler/mini-room-cooler-18l.svg"
  },
  {
    "id": 7,
    "name": "Honeycomb Pad Cooler 70L",
    "price": 11999,
    "mrp": 14999,
    "rating": 4.8,
    "description": "70 litre cooler with a 3-side honeycomb pad for strong cooling.",
    "image": "/images/aircooler/honeycomb-pad-cooler-70l.svg"
  },
  {
    "id": 8,
    "name": "Smart Wi-Fi Tower 45L",
    "price": 12499,
    "mrp": 15999,
    "rating": 4.3,
    "description": "Tower cooler you can switch on from your phone, with a timer and a remote.",
    "image": "/images/aircooler/smart-wi-fi-tower-45l.svg",
    "tag": "New"
  }
];
