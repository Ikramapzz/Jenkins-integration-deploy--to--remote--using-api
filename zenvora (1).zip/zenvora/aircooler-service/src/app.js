"use strict";
const http = require("http");
const products = require("./data");
const meta = require("./meta");

function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
    "Access-Control-Allow-Origin": "*",
  });
  res.end(payload);
}

function num(value) {
  if (value === null || value === "") return null;
  const n = Number(value);
  return Number.isNaN(n) ? null : n;
}

function listProducts(query) {
  let list = products.slice();
  const q = (query.get("q") || "").trim().toLowerCase();
  if (q) {
    list = list.filter(
      (p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
    );
  }
  const min = num(query.get("minPrice"));
  const max = num(query.get("maxPrice"));
  if (min !== null) list = list.filter((p) => p.price >= min);
  if (max !== null) list = list.filter((p) => p.price <= max);

  switch (query.get("sort")) {
    case "price_asc":
      list.sort((a, b) => a.price - b.price);
      break;
    case "price_desc":
      list.sort((a, b) => b.price - a.price);
      break;
    case "rating":
      list.sort((a, b) => b.rating - a.rating);
      break;
    default:
      break;
  }
  return list;
}

function createServer() {
  return http.createServer((req, res) => {
    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
      });
      return res.end();
    }
    if (req.method !== "GET") return send(res, 405, { error: "Method not allowed" });

    const url = new URL(req.url, "http://localhost");
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (path === "/health") return send(res, 200, { status: "UP", service: meta.key + "-service" });
    if (path === "/meta") return send(res, 200, Object.assign({}, meta, { count: products.length }));
    if (path === "/products") return send(res, 200, listProducts(url.searchParams));

    const match = path.match(/^\/products\/(\d+)$/);
    if (match) {
      const item = products.find((p) => p.id === Number(match[1]));
      if (!item) return send(res, 404, { error: "Product not found" });
      return send(res, 200, item);
    }
    return send(res, 404, { error: "Route not found" });
  });
}

module.exports = { createServer, listProducts };
