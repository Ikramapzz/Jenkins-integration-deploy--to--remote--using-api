"use strict";
module.exports = {
  "key": "specs",
  "label": "Specs",
  "tagline": "Eyeglass frames for work, school and style",
  "port": 3006
};
