"use strict";
// Add a product by appending an object here and dropping its image in frontend/public/images/specs/
module.exports = [
  {
    "id": 1,
    "name": "Round Metal Frame",
    "price": 1499,
    "mrp": 2199,
    "rating": 4.4,
    "description": "Thin round metal frame with adjustable nose pads and spring hinges.",
    "image": "/images/specs/round-metal-frame.svg",
    "tag": "Bestseller"
  },
  {
    "id": 2,
    "name": "Rimless Titanium",
    "price": 3499,
    "mrp": 4999,
    "rating": 3.9,
    "description": "Featherweight titanium rimless frame that weighs under 10 grams.",
    "image": "/images/specs/rimless-titanium.svg"
  },
  {
    "id": 3,
    "name": "Cat-Eye Acetate",
    "price": 1999,
    "mrp": 2899,
    "rating": 4.6,
    "description": "Hand-polished acetate frame with a lifted cat-eye shape.",
    "image": "/images/specs/cat-eye-acetate.svg"
  },
  {
    "id": 4,
    "name": "Classic Wayfarer Clear",
    "price": 1699,
    "mrp": 2399,
    "rating": 4.1,
    "description": "Clear wayfarer frame that suits most face shapes.",
    "image": "/images/specs/classic-wayfarer-clear.svg"
  },
  {
    "id": 5,
    "name": "Blue-Light Computer Glasses",
    "price": 1299,
    "mrp": 1999,
    "rating": 4.8,
    "description": "Lenses that filter blue light for long hours in front of a screen.",
    "image": "/images/specs/blue-light-computer-glasses.svg"
  },
  {
    "id": 6,
    "name": "Half-Rim Browline",
    "price": 2199,
    "mrp": 3099,
    "rating": 4.3,
    "description": "Browline frame with a metal lower rim and a slim acetate top.",
    "image": "/images/specs/half-rim-browline.svg"
  },
  {
    "id": 7,
    "name": "Kids Flex Frame",
    "price": 999,
    "mrp": 1499,
    "rating": 3.8,
    "description": "Soft silicone frame that bends without breaking, for ages 4 to 12.",
    "image": "/images/specs/kids-flex-frame.svg"
  },
  {
    "id": 8,
    "name": "Progressive-Ready Square",
    "price": 3999,
    "mrp": 5499,
    "rating": 4.5,
    "description": "Deeper square lens area, ready for progressive lens fitting.",
    "image": "/images/specs/progressive-ready-square.svg",
    "tag": "New"
  }
];
