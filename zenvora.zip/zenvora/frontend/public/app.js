(() => {
  "use strict";

  const COLORS = {
    clothes: "#3D5A80",
    tshirts: "#C8421F",
    watches: "#A87A0A",
    aircooler: "#1D7FC4",
    coolingglass: "#7B4FD6",
    specs: "#2E9D6B",
    washingmachine: "#4A5568",
  };
  const CART_KEY = "zenvora_cart_v1";
  const inr = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });

  const state = { cats: [], products: {}, query: "", sort: {}, cart: loadCart() };
  const $ = (sel, root = document) => root.querySelector(sel);

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v === null || v === undefined) continue;
      if (k === "class") el.className = v;
      else if (k === "text") el.textContent = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) {
      if (kid === null || kid === undefined || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  function loadCart() {
    try {
      const raw = JSON.parse(localStorage.getItem(CART_KEY));
      return raw && typeof raw === "object" ? raw : {};
    } catch (e) {
      return {};
    }
  }
  function saveCart() {
    try { localStorage.setItem(CART_KEY, JSON.stringify(state.cart)); } catch (e) { /* storage unavailable */ }
  }

  async function api(path) {
    const res = await fetch("/api" + path);
    if (!res.ok) throw new Error("Request failed: " + path);
    return res.json();
  }

  function toast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toast.t);
    toast.t = setTimeout(() => el.classList.remove("show"), 2600);
  }

  const discount = (p) => Math.round((1 - p.price / p.mrp) * 100);
  const cartKey = (cat, id) => cat + ":" + id;

  /* ---------- cart ---------- */
  function addToCart(cat, product) {
    const key = cartKey(cat, product.id);
    const line = state.cart[key] || { cat, id: product.id, name: product.name, price: product.price, image: product.image, qty: 0 };
    line.qty += 1;
    state.cart[key] = line;
    saveCart();
    renderCart();
    toast(product.name + " added to cart");
  }
  function changeQty(key, delta) {
    const line = state.cart[key];
    if (!line) return;
    line.qty += delta;
    if (line.qty <= 0) delete state.cart[key];
    saveCart();
    renderCart();
  }
  function renderCart() {
    const lines = Object.entries(state.cart);
    const total = lines.reduce((sum, [, l]) => sum + l.price * l.qty, 0);
    const count = lines.reduce((sum, [, l]) => sum + l.qty, 0);
    $("#cart-count").textContent = count;
    $("#cart-total").textContent = inr.format(total);
    $("#checkout").disabled = count === 0;
    const list = $("#cart-items");
    list.replaceChildren();
    if (!lines.length) {
      list.append(h("li", { class: "empty", text: "Your cart is empty. Pick something from any shop to start." }));
      return;
    }
    for (const [key, l] of lines) {
      list.append(
        h("li", {},
          h("img", { src: l.image, alt: "", width: 72, height: 54 }),
          h("div", {},
            h("h3", { text: l.name }),
            h("div", { class: "line" },
              h("span", { class: "qty" },
                h("button", { type: "button", "aria-label": "Remove one " + l.name, onclick: () => changeQty(key, -1), text: "\u2212" }),
                h("span", { text: l.qty }),
                h("button", { type: "button", "aria-label": "Add one " + l.name, onclick: () => changeQty(key, 1), text: "+" })),
              h("strong", { text: inr.format(l.price * l.qty) }),
              h("button", { type: "button", class: "link", onclick: () => changeQty(key, -l.qty), text: "Remove" })))
        )
      );
    }
  }
  let lastFocus = null;
  function openCart() {
    lastFocus = document.activeElement;
    $("#scrim").hidden = false;
    const cart = $("#cart");
    cart.removeAttribute("inert");
    cart.setAttribute("aria-hidden", "false");
    cart.classList.add("open");
    $("#close-cart").focus();
  }
  function closeCart() {
    const cart = $("#cart");
    cart.classList.remove("open");
    cart.setAttribute("aria-hidden", "true");
    cart.setAttribute("inert", "");
    $("#scrim").hidden = true;
    if (lastFocus) lastFocus.focus();
  }
  function checkout() {
    state.cart = {};
    saveCart();
    renderCart();
    closeCart();
    toast("Order placed. This is a demo, so nothing was charged.");
  }

  /* ---------- product detail ---------- */
  function openDetail(cat, p) {
    const dlg = $("#detail");
    dlg.replaceChildren(
      h("div", { class: "detail-grid" },
        h("img", { src: p.image, alt: p.name, width: 480, height: 360 }),
        h("div", { class: "detail-info" },
          h("h2", { id: "detail-name", text: p.name }),
          h("span", { class: "rating", text: "\u2605 " + p.rating.toFixed(1) + " rating" }),
          h("p", { text: p.description }),
          h("div", { class: "price" },
            h("strong", { text: inr.format(p.price) }),
            h("s", { text: inr.format(p.mrp) }),
            h("em", { text: discount(p) + "% off" })),
          h("div", { class: "detail-actions" },
            h("button", { type: "button", class: "primary", onclick: () => { addToCart(cat, p); dlg.close(); }, text: "Add to cart" }),
            h("button", { type: "button", class: "ghost", onclick: () => dlg.close(), text: "Close" })))
      )
    );
    dlg.showModal();
  }

  /* ---------- catalogue ---------- */
  function sorted(list, mode) {
    const out = list.slice();
    if (mode === "price_asc") out.sort((a, b) => a.price - b.price);
    else if (mode === "price_desc") out.sort((a, b) => b.price - a.price);
    else if (mode === "rating") out.sort((a, b) => b.rating - a.rating);
    return out;
  }
  function matches(p, q) {
    return !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
  }

  function productCard(cat, p) {
    return h("article", { class: "card" },
      h("button", { type: "button", class: "card-open", "aria-label": "View " + p.name, onclick: () => openDetail(cat, p) },
        h("img", { src: p.image, alt: p.name, loading: "lazy", width: 480, height: 360 }),
        p.tag ? h("span", { class: "badge", text: p.tag }) : null),
      h("div", { class: "card-body" },
        h("h3", { text: p.name }),
        h("span", { class: "rating", text: "\u2605 " + p.rating.toFixed(1) }),
        h("div", { class: "price" },
          h("strong", { text: inr.format(p.price) }),
          h("s", { text: inr.format(p.mrp) }),
          h("em", { text: discount(p) + "% off" }))),
      h("button", { type: "button", class: "add", onclick: () => addToCart(cat, p), "aria-label": "Add " + p.name + " to cart", text: "Add to cart" })
    );
  }

  function renderShops() {
    const main = $("#shop");
    main.replaceChildren();
    const q = state.query.trim().toLowerCase();
    let shown = 0;

    for (const cat of state.cats) {
      const all = state.products[cat.key] || [];
      const visible = sorted(all.filter((p) => matches(p, q)), state.sort[cat.key]);
      if (q && !visible.length) continue;
      shown += visible.length;

      const select = h("select", { id: "sort-" + cat.key, onchange: (e) => { state.sort[cat.key] = e.target.value; renderShops(); } },
        h("option", { value: "", text: "Featured" }),
        h("option", { value: "price_asc", text: "Price, low to high" }),
        h("option", { value: "price_desc", text: "Price, high to low" }),
        h("option", { value: "rating", text: "Top rated" }));
      select.value = state.sort[cat.key] || "";

      const section = h("section", { class: "shop", id: "shop-" + cat.key, "aria-labelledby": "h-" + cat.key },
        h("div", { class: "shop-head" },
          h("div", {},
            h("h2", { id: "h-" + cat.key, text: cat.label }),
            h("p", { text: cat.tagline })),
          h("label", { class: "sort" }, "Sort by", select)),
        cat.available === false
          ? h("div", { class: "message" }, h("h2", { text: "This shop is closed for a moment" }), h("p", { text: "Try again in a minute." }))
          : h("div", { class: "grid" }, visible.map((p) => productCard(cat.key, p))));
      section.style.setProperty("--c", COLORS[cat.key] || "#0F8B8D");
      main.append(section);
    }

    if (q && shown === 0) {
      main.append(h("div", { class: "message" },
        h("h2", { text: "No products match \u201C" + state.query.trim() + "\u201D" }),
        h("p", { text: "Try a shorter word, like \u201Cshirt\u201D or \u201Ccooler\u201D." })));
    }
  }

  function renderTiles() {
    const nav = $("#tiles");
    nav.replaceChildren();
    for (const cat of state.cats) {
      const first = (state.products[cat.key] || [])[0];
      const a = h("a", { class: "tile", href: "#shop-" + cat.key },
        first ? h("img", { src: first.image, alt: "", width: 480, height: 360 }) : null,
        h("span", {}, cat.label, h("small", { text: (state.products[cat.key] || []).length + " products" })));
      a.style.setProperty("--c", COLORS[cat.key] || "#0F8B8D");
      nav.append(a);
    }
  }

  async function init() {
    renderCart();
    try {
      state.cats = await api("/categories");
      await Promise.all(
        state.cats.map(async (cat) => {
          if (cat.available === false) { state.products[cat.key] = []; return; }
          state.products[cat.key] = await api("/" + cat.key + "/products");
        })
      );
      renderTiles();
      renderShops();
    } catch (err) {
      $("#shop").replaceChildren(h("div", { class: "message" },
        h("h2", { text: "Products could not be loaded" }),
        h("p", { text: "Refresh the page. If it keeps failing, try again in a minute." })));
    }
  }

  let searchTimer;
  $("#search").addEventListener("input", (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.query = e.target.value; renderShops(); }, 150);
  });
  $("#open-cart").addEventListener("click", openCart);
  $("#close-cart").addEventListener("click", closeCart);
  $("#scrim").addEventListener("click", closeCart);
  $("#checkout").addEventListener("click", checkout);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $("#cart").classList.contains("open")) closeCart(); });

  init();
})();
