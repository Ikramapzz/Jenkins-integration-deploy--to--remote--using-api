"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { createServer } = require("../src/app");
const products = require("../src/data");
const meta = require("../src/meta");

let server;
let base;

before(async () => {
  server = createServer();
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  base = "http://127.0.0.1:" + server.address().port;
});

after(() => new Promise((resolve) => server.close(resolve)));

const get = async (path) => {
  const res = await fetch(base + path);
  return { status: res.status, body: await res.json() };
};

test("health returns UP", async () => {
  const { status, body } = await get("/health");
  assert.equal(status, 200);
  assert.equal(body.status, "UP");
  assert.equal(body.service, meta.key + "-service");
});

test("meta describes the category", async () => {
  const { status, body } = await get("/meta");
  assert.equal(status, 200);
  assert.equal(body.key, meta.key);
  assert.equal(body.count, products.length);
});

test("catalogue has at least 8 products", async () => {
  const { body } = await get("/products");
  assert.ok(body.length >= 8, "expected 8+ products, got " + body.length);
});

test("every product has the required shape", async () => {
  const { body } = await get("/products");
  for (const p of body) {
    assert.equal(typeof p.id, "number");
    assert.ok(p.name && p.description);
    assert.ok(p.price > 0 && p.price <= p.mrp, p.name + " price must be positive and <= mrp");
    assert.ok(p.rating >= 1 && p.rating <= 5);
    assert.match(p.image, new RegExp("^/images/" + meta.key + "/[a-z0-9-]+\\.svg$"));
  }
});

test("product ids are unique", async () => {
  const { body } = await get("/products");
  assert.equal(new Set(body.map((p) => p.id)).size, body.length);
});

test("search matches by name", async () => {
  const word = products[0].name.split(" ")[0];
  const { body } = await get("/products?q=" + encodeURIComponent(word.toLowerCase()));
  assert.ok(body.length >= 1);
  assert.ok(body.some((p) => p.id === products[0].id));
});

test("search with no match returns an empty list", async () => {
  const { status, body } = await get("/products?q=zzzz-no-such-item");
  assert.equal(status, 200);
  assert.deepEqual(body, []);
});

test("maxPrice and minPrice filters work", async () => {
  const prices = products.map((p) => p.price).sort((a, b) => a - b);
  const mid = prices[Math.floor(prices.length / 2)];
  const low = await get("/products?maxPrice=" + mid);
  assert.ok(low.body.length > 0);
  low.body.forEach((p) => assert.ok(p.price <= mid));
  const high = await get("/products?minPrice=" + mid);
  high.body.forEach((p) => assert.ok(p.price >= mid));
});

test("sort by price ascending and descending", async () => {
  const asc = (await get("/products?sort=price_asc")).body.map((p) => p.price);
  const desc = (await get("/products?sort=price_desc")).body.map((p) => p.price);
  assert.deepEqual(asc, asc.slice().sort((a, b) => a - b));
  assert.deepEqual(desc, desc.slice().sort((a, b) => b - a));
});

test("invalid price filter is ignored instead of crashing", async () => {
  const { status, body } = await get("/products?maxPrice=abc");
  assert.equal(status, 200);
  assert.equal(body.length, products.length);
});

test("get product by id", async () => {
  const { status, body } = await get("/products/" + products[0].id);
  assert.equal(status, 200);
  assert.equal(body.name, products[0].name);
});

test("unknown product id returns 404", async () => {
  const { status, body } = await get("/products/99999");
  assert.equal(status, 404);
  assert.ok(body.error);
});

test("unknown route returns 404", async () => {
  const { status } = await get("/nothing-here");
  assert.equal(status, 404);
});

test("non-GET methods are rejected", async () => {
  const res = await fetch(base + "/products", { method: "POST" });
  assert.equal(res.status, 405);
});
