# Zenvora

Multi-shop store built as microservices. Each shop is its own Node service with its own catalogue and tests.

```
frontend (nginx :80)  ->  gateway (:8080)  ->  clothes-service     :3001
                                           ->  tshirts-service     :3002
                                           ->  watches-service     :3003
                                           ->  aircooler-service   :3004
                                           ->  coolingglass-service:3005
                                           ->  specs-service       :3006
                                           ->  washingmachine-service :3007
```

62 products across 7 shops. The services have no npm dependencies, so there is nothing to install. Needs Node 22+ for tests.

## Run it

```bash
docker compose up -d --build
# open http://localhost        (WEB_PORT=8081 docker compose up -d  if port 80 is busy)
# API:  http://localhost:8080/api/watches/products
```

API per shop: `GET /api/<shop>/products?q=&minPrice=&maxPrice=&sort=price_asc|price_desc|rating`, `GET /api/<shop>/products/:id`, and `GET /api/categories`.

## QA, step by step

```bash
# 1. unit + API tests (all services)
for d in gateway *-service; do (cd $d && npm run lint && npm test); done

# 2. data and image validation
node qa/validate-assets.js

# 3. full-stack smoke test (stack must be running)
WEB_URL=http://localhost API_URL=http://localhost:8080 ./qa/smoke.sh
```

The full list of checks is in `qa/TEST_PLAN.md`.

## Jenkins setup

1. Push this folder to a Git repo and create a Multibranch Pipeline job pointing at it.
2. Edit `environment` in the `Jenkinsfile`: `REGISTRY`, `REMOTE_USER`, `REMOTE_HOST`, `REMOTE_DIR`.
3. Add credentials: `registry-creds` (username and password) and `remote-server-ssh` (SSH private key).
4. For SonarQube: add a server named `sonarqube` under Manage Jenkins > System and install the SonarQube Scanner. Untick RUN_SONAR to skip.
5. Agent needs Node 22+, Docker with Compose v2 and curl. Trivy is optional (untick RUN_TRIVY to skip).
6. Stages: Checkout, Static Check, Unit and API Tests, Data and Asset Validation, SonarQube, Quality Gate, Docker Build, Trivy, Integration Smoke Test, Push Images and Deploy (main branch only), Post-Deploy Check.

## Add more products

1. Open `<shop>-service/src/data.js` and append an object with the next `id`.
2. Put the image at `frontend/public/images/<shop>/<name>.svg` (or .jpg/.png, and update the `image` path in the data file).
3. Run `node qa/validate-assets.js`. It fails if an image is missing or a price is above MRP.

## About the images

The 62 product images are SVG illustrations drawn for this project, not photographs. To use real photos, save them under `frontend/public/images/<shop>/` and change the `image` field of each product to the new filename. Use photos you own or that are licensed for commercial use.
